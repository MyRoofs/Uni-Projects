#include <stdio.h>

float accounts[5][2] = { {1234123412341234,1500},{1235456215469874,2000},{5612329456120216,1350},{9654123549876521,1200},{5210032110659845,5000} };
int i;
float pan;
int isValidAccount() {
    dataCheck = 0;
    for (i = 0; i < 5; i++)
    {
        if (pan == accounts[i][0]) {
            printf("Account is valid.");
            dataCheck = 0;
            break;
        }
        else {
            dataCheck++;
        }
    }
    if (dataCheck == 5) {
        printf("Declined. Invalid account. \n");
        dataCheck == 1;
    }
    return 0;
}

int isAmountAvailable() {
    if (accounts[i][1] >= price) {
        printf("Purchase done. Thank you! \n");
    }
    else {
        printf("Insuffiecient amounts. \n");;
    }
}





#include <stdio.h>

float accounts[5][2] = { {1234123412341234,1500},{1235456215469874,2000},{5612329456120216,1350},{9654123549876521,1200},{5210032110659845,5000} };
int i;
float pan;
int isValidAccount() {
    dataCheck = 0;
    for (i = 0; i < 5; i++)
    {
        if (pan == accounts[i][0]) {
            printf("Account is valid.");
            dataCheck = 0;
            break;
        }
        else {
            dataCheck++;
        }
    }
    if (dataCheck == 5) {
        printf("Declined. Invalid account. \n");
        dataCheck == 1;
    }
    return 0;
}

int isAmountAvailable() {
    if (accounts[i][1] >= price) {
        printf("Purchase done. Thank you! \n");
    }
    else {
        printf("Insuffiecient amounts. \n");;
    }
}





