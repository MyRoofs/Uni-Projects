#include <stdio.h>
#pragma warning(disable : 4996).
int getCardHolderName(char name[100])
{
	printf("Please enter the card holder's name: \n");
	scanf("%s", name);
	return 0;
}
int Exyear, Exmonth;
int year, month, dataCheck;
float pan;
float MaxLimit, price;
int getCardExpiryDate()
{
#pragma warning(disable : 4996).

	printf("PLease enter the month of expiration \n");
	scanf("%d", &Exmonth);
	printf("PLease enter the year of expiration: \n");
	scanf("%d", &Exyear);

	return 0;
}

int getCardPAN()
{
#pragma warning(disable : 4996).
	printf("PLease enter card PAN:\n");
	scanf("%f", &pan);
	return 0;
}