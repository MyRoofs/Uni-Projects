#include <stdio.h>
#include "card.h"
#include "server.h"
#include "terminal.h"
#pragma warning(disable : 4996).
char name[100];
int Exmonth, month, dataCheck;
int Exyear, year;
float price;
int main()
{
    while (1) {
        while (1) {
            dataCheck = 0;
            getCardHolderName(name);
            getCardExpiryDate();
            getCardPAN(pan);
            getTransactionDate();
            isCardExpired();
            if (dataCheck == 1) {
                break;

            }
            else {
                getTransactionAmount();
                setMax();
                isBelowMax();
                if (dataCheck == 1) {
                    break;

                }
                else {
                    isValidAccount();
                    if (dataCheck == 1) {
                        break;

                    }
                    else {
                        isAmountAvailable();
                        if (dataCheck == 1) {
                            break;
                        }
                        else {
                            saveTrans();
                        }

                    }




                }

            }

        }
    }
    return 0;

}
