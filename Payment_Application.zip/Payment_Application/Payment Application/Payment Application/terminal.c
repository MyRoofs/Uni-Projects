#include <stdio.h>
#pragma warning(disable : 4996).

int getTransactionDate()
{
	printf("Please enter the current month: \n");
	scanf("%d", &month);
	printf("Please enter the current year: \n");
	scanf("%d", &year);
	return 0;
}

int isCardExpired()
{
	if (year == Exyear)
	{
		if (month <= Exmonth) {
			printf("Accepted card.\n");
			dataCheck = 0;
		}
		else {
			printf("Decline. Expired card.\n");
			dataCheck = 1;
		}
	}
	else if (year > Exyear) {
		printf("Decline. Expired card.\n");
		dataCheck = 1;
	}
	else {
		printf("Accepted card.\n");
		dataCheck = 0;
	}
	return 0;
}

int getTransactionAmount()
{
	printf("Please enter the price of the product: \n");
	scanf("%f", &price);
	return 0;
}
int setMax()
{
	printf("PLease enter the card's maximum limit: \n");
	scanf("%f", &MaxLimit);
	return 0;
}
int isBelowMax()
{
	if (MaxLimit >= price) {
		printf("The card's limit can buy this item. \n");
		dataCheck = 0;
	}
	else {
		printf("Purchase declined. Price is exceeding maximum limit of the card. \n");
		dataCheck = 0;
	}
	return 0;
}
